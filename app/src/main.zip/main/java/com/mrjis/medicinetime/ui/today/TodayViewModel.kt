package com.mrjis.medicinetime.ui.today

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mrjis.medicinetime.AppContainer
import com.mrjis.medicinetime.alarm.DoseRequest
import com.mrjis.medicinetime.alarm.DoseUndo
import com.mrjis.medicinetime.data.local.entity.ProfileEntity
import com.mrjis.medicinetime.domain.dose.TodayDose
import com.mrjis.medicinetime.domain.dose.TodayGroup
import com.mrjis.medicinetime.domain.dose.TodayPlanner
import com.mrjis.medicinetime.domain.dose.TodayStatus
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.ConcurrentHashMap

data class TodayUiState(
    val loaded: Boolean = false,
    val profile: ProfileEntity? = null,
    val groups: List<TodayGroup> = emptyList(),
    /** Doses missed in the last 24 hours (yesterday and today), oldest first. */
    val missed: List<TodayDose> = emptyList(),
    val nowMillis: Long = 0L
) {
    val totalCount: Int get() = groups.sumOf { it.doses.size }
    val takenCount: Int
        get() = groups.sumOf { group -> group.doses.count { it.status == TodayStatus.TAKEN } }
}

/** One-time messages for the screen (it shows a snackbar with Undo). */
sealed interface TodayEvent {
    data class Taken(
        val profileId: String,
        val undos: List<DoseUndo>,
        val count: Int,
        /** Name of the medicine when exactly one was taken. */
        val singleName: String?
    ) : TodayEvent
}

@OptIn(ExperimentalCoroutinesApi::class)
class TodayViewModel(private val container: AppContainer) : ViewModel() {

    private val zone: ZoneId get() = ZoneId.systemDefault()

    /** Emits the current time now and every 30 seconds, so UPCOMING -> DUE -> MISSED updates by itself. */
    private val ticker: Flow<Long> = flow {
        while (true) {
            emit(System.currentTimeMillis())
            delay(TICK_MILLIS)
        }
    }

    val state: StateFlow<TodayUiState> = container.currentProfileProvider.current
        .flatMapLatest { profile ->
            if (profile == null) flowOf(TodayUiState(loaded = true)) else planFor(profile)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), TodayUiState())

    private val _events = MutableSharedFlow<TodayEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<TodayEvent> = _events.asSharedFlow()

    /** Doses being written right now, so a fast double tap cannot write (and undo) twice. */
    private val inFlight: MutableSet<String> = ConcurrentHashMap.newKeySet()

    private fun planFor(profile: ProfileEntity): Flow<TodayUiState> {
        // The date changes at midnight, which switches the log range we listen to.
        val dates = ticker.map { toDate(it) }.distinctUntilChanged()
        val logs = dates.flatMapLatest { date ->
            // One extra day back, because yesterday is planned too (missed warning card).
            val (from, to) = TodayPlanner.logRange(date, zone, extraDaysBack = 1)
            container.doseLogDao.observeBetween(profile.id, from, to)
        }
        return combine(
            container.medicineRepository.observeForProfile(profile.id),
            logs,
            ticker
        ) { medicines, logList, now ->
            val date = toDate(now)
            val today = TodayPlanner.plan(medicines, profile, date, logList, now, zone)
            val yesterday = TodayPlanner.plan(medicines, profile, date.minusDays(1), logList, now, zone)
            TodayUiState(
                loaded = true,
                profile = profile,
                groups = today,
                missed = TodayPlanner.recentMissed(yesterday + today, now),
                nowMillis = now
            )
        }
    }

    /**
     * Marks doses as taken (early, on time or late) and tells the screen to show Undo.
     * Used by the timeline buttons and by "Taken late" on the missed card.
     */
    fun take(profileId: String, doses: List<TodayDose>) {
        // Ignore a second tap on doses that are already taken, so Undo always reverts the real change.
        val alreadyTaken = state.value.groups
            .flatMap { it.doses }
            .filter { it.status == TodayStatus.TAKEN }
            .map { it.logId }
            .toSet()
        val todo = doses
            .filter { it.logId !in alreadyTaken }
            .filter { inFlight.add(it.logId) } // false when this dose is already being written
        if (todo.isEmpty()) return

        // appScope, so the write is never cancelled if the screen is closed right after the tap.
        container.appScope.launch {
            try {
                val undos = container.doseActions.takeScheduled(
                    profileId,
                    todo.map { DoseRequest(it.medicineId, it.scheduledAtMillis, it.doseAmount) }
                )
                _events.emit(
                    TodayEvent.Taken(
                        profileId = profileId,
                        undos = undos,
                        count = todo.size,
                        singleName = todo.singleOrNull()?.medicineName
                    )
                )
            } finally {
                todo.forEach { inFlight.remove(it.logId) }
            }
        }
    }

    fun undo(event: TodayEvent.Taken) {
        container.appScope.launch { container.doseActions.undo(event.profileId, event.undos) }
    }

    private fun toDate(millis: Long): LocalDate =
        Instant.ofEpochMilli(millis).atZone(zone).toLocalDate()

    private companion object {
        const val TICK_MILLIS = 30_000L
    }
}